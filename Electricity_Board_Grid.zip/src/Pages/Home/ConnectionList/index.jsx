import { useRef, useEffect, useState, useCallback } from 'react';
import { Box, Table, Pagination, TextInput } from '@mantine/core';
import { useStyles } from './style';
import edit from "../../../assets/icons/edit.svg"
import filter from "../../../assets/icons/filterIcon.svg"
import { Link } from 'react-router-dom';
import SearchIcon from '../../../assets/icons/search.svg';
import { data, statusClass } from './properties';
import { backendBaseURL, getHeader } from '../../../Utils/connection';
import FilterModal from '../FilterModal';
import { TableVirtuoso } from 'react-virtuoso';

function ConnectionList() {
    const { classes } = useStyles();
    const [entries, setEntries] = useState([]);
    const [pageLoadEntries, setPageLoadEntries] = useState([]);
    const [totalPage, setTotalPage] = useState(1);
    const [pageSize] = useState(10);
    const [openFilterModal, setOpenFilterModal] = useState(false);
    const [filteredValue, setFilteredValue] = useState([null, null]);
    const [loading, setLoading] = useState(false);
    const cacheListing = useRef({});
    const [activePage, setActivePage] = useState(1);
    const params = new URLSearchParams();

    const fetchConnectionList = useCallback(async (isReset = false) => {
        if (!isReset && filteredValue && filteredValue[0] && filteredValue[1]) {
            params.delete('datemin');
            params.delete('datemax');
            params.append('datemin', filteredValue[0].toISOString());
            params.append('datemax', filteredValue[1].toISOString());
        }
        params.append('page', activePage);
        params.append('pSize', pageSize);

        if (!isReset && params.toString() in cacheListing.current) {
            setEntries(prevEntries => [...prevEntries, ...cacheListing.current[params.toString()]]);
            return;
        }

        setLoading(true);

        try {
            const response = await fetch(`${backendBaseURL}/user/list?` + params.toString(), {
                method: 'GET',
                headers: getHeader(),
            });

            if (response.ok) {
                const UserListing = await response.json();
                setEntries(prevEntries => [...prevEntries, ...UserListing.data]);
                setPageLoadEntries(prevEntries => [...prevEntries, ...UserListing.data]);
                setTotalPage((UserListing.totalCount + pageSize - 1) / pageSize);
                cacheListing.current[params.toString()] = UserListing.data;
            }
        } catch (error) {
            console.error('Error fetching data:', error);
        } finally {
            setLoading(false);
        }
    }, [activePage, filteredValue]);

    useEffect(() => {
        fetchConnectionList(true);
    }, [fetchConnectionList]);

    useEffect(() => {
        const handleScroll = () => {
            if (window.innerHeight + document.documentElement.scrollTop !== document.documentElement.offsetHeight || loading) return;
            setActivePage(prevPage => prevPage + 1);
        };

        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, [loading, fetchConnectionList]);

    const handleSearch = (e) => {
        const value = e.target.value;
        if (value === "") {
            setEntries(pageLoadEntries);
        } else {
            const filteredEntries = pageLoadEntries.filter(item =>
                `${item.Applicant_Name.toLowerCase()}`.includes(value.toLowerCase()) ||
                item.Reviewer_Name.toLowerCase().includes(value) ||
                item.Status.toLowerCase().includes(value)
            );
            setEntries(filteredEntries);
        }
    }

    const AppliedDateFilter = async (isReset) => {
        console.log('filteredValue is ', filteredValue);

        await fetchConnectionList(isReset);
        setOpenFilterModal(false);
    }

    const rows = entries.map((element, index) => (
        <tr className={index % 2 === 0 ? classes.tableRowWhite : classes.tableRow} key={`${element.firstName}${index}`}>
            <td className={classes.tableData}>{element.Applicant_Name}</td>
            <td className={classes.tableData}>{element.Reviewer_Name}</td>
            <td className={classes.tableData}>{new Date(element.Date_of_Application).toDateString()}</td>
            <td className={` ${classes.tableData} ${classes.statusWrapper}`}>
                <p className={`${classes.status} ${statusClass(element.Status.toLowerCase(), classes)}`}>{element.Status}</p>
            </td>
            <td className={classes.tableData}>
                <Box className={classes.editAndView}>
                    <Link to={`/details/${element.ID}`}>
                        <img className={classes.action} src={edit} alt='edit' />
                    </Link>
                </Box>
            </td>
        </tr>
    ));

    return (
        <Box className={classes.wrapper}>
            <Box className={classes.headerAndSearch}>
                <p className={classes.title}>
                    {data.titles.connectionList} : {filteredValue && filteredValue[0] && filteredValue[1] ? filteredValue[0].toDateString() + '-' + filteredValue[1].toDateString() : ''}
                </p>
                <Box className={classes.searchAndFilter}>
                    <TextInput
                        icon={<img className={classes.action} src={SearchIcon} alt='view' />}
                        onChange={handleSearch}
                        radius={"xl"}
                        className={classes.searchInput}
                        placeholder={data.titles.search}
                    />
                    <Box className={classes.filterContainer} onClick={() => { setOpenFilterModal(true) }}>
                        <img className={classes.filterIcon} src={filter} alt='search-input' />
                        <p className={classes.filter}>{data.titles.filter}</p>
                    </Box>
                </Box>
            </Box>
            <Box className={classes.tableContainer}>
                <TableVirtuoso
                    data={entries}
                    fixedHeaderContent={() => (
                        <tr>
                            {data.tableHeading.map(heading => (
                                <th className={classes.columnHeading} key={heading}>{heading}</th>
                            ))}
                        </tr>
                    )}
                    itemContent={(index, element) => (
                        <tr className={index % 2 === 0 ? classes.tableRowWhite : classes.tableRow} key={`${element.firstName}${index}`}>
                            <td className={classes.tableData}>{element.Applicant_Name}</td>
                            <td className={classes.tableData}>{element.Reviewer_Name}</td>
                            <td className={classes.tableData}>{new Date(element.Date_of_Application).toDateString()}</td>
                            <td className={` ${classes.tableData} ${classes.statusWrapper}`}>
                                <p className={`${classes.status} ${statusClass(element.Status.toLowerCase(), classes)}`}>{element.Status}</p>
                            </td>
                            <td className={classes.tableData}>
                                <Box className={classes.editAndView}>
                                    <Link to={`/details/${element.ID}`}>
                                        <img className={classes.action} src={edit} alt='edit' />
                                    </Link>
                                </Box>
                            </td>
                        </tr>
                    )}
                    style={{ height: 400 }}
                />
            </Box>
            {rows.length === 0 ? <p className='no-record-found'>{"No record found"}</p> : null}
            <FilterModal
                openFilterModal={openFilterModal}
                setOpenFilterModal={setOpenFilterModal}
                applyFilter={AppliedDateFilter}
                filteredValue={filteredValue}
                setFilteredValue={setFilteredValue}
            />
        </Box>
    );
}

export default ConnectionList;
