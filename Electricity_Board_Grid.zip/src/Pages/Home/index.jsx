import ConnectionList from './ConnectionList';
import ConnectionChart from './ConnectionChart'
const Home = () => {

  return<>
    <ConnectionChart />
    <ConnectionList />
  </>
}

export default Home;